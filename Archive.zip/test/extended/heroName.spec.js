import exp from "../../data/expected.json";
import sel from "../../data/selectors";

describe('My Little Hero', function () {

    describe('Getting to the page', function () {

        before('Open App', function () {
            browser.url('');
        });

        xit('TC-028 Name field placeholder= "Hero\'s name"', function () {
            const namePlaceholder = $(sel.name).getAttribute('placeholder');
            expect(namePlaceholder).toEqual(exp.namePlaceholder);
        });

        xit('TC-029 The cursor blinks in field', function () {
            $(sel.name).click();
            expect($(sel.name).isFocused()).toEqual(true);
        });

        xit('TC-030 Verify that the Name field frame turns from grey to blue when hover the field', function () {
            $(sel.name).moveTo();
            const hover = $(sel.name);
            const hoverBorderColor = hover.getCSSProperty('border-top-color');
            expect(hoverBorderColor).toContain('rgba(145,195,235,1)');
        });

        xit('TC-031 Verify that the Name field frame turns from grey to blue when hover the field', function () {
            $(sel.name).click();
            const click = $(sel.name)
            const clickBorderColor = click.getCSSProperty('border-color');
            expect(clickBorderColor).toContain('#40a9ff');

        });


    });
});
